# Sample Node.js Project

A Node.js project written using Express. EJS was used as the view engine.

# Installation

You need to write the following commands on the terminal screen so that you can run the project locally.

```sh

1. cd sample-node-project
2. npm install
3. npm start
```

The application is running on [localhost](http://localhost:3000).
